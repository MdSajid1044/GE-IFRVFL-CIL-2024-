Support Vector Machines using Intrinsic and Penalty Graphs (GESVM)

Main functions: 
calc_ge_data.m --> linear case
calc_ge_kernel.m --> kernel case

Examples of usage: example_of_usage_linear.m and example_of_usage.m

A. Iosifidis and M. Gabbouj, "Multi-class Support Vector Machine Classifiers using Intrinsic and Penalty Graphs", Pattern Recognition, vol. 55, pp. 231-246, 2016
