function result = relu(x)
%implement relu function
result = max(0,x);
end

